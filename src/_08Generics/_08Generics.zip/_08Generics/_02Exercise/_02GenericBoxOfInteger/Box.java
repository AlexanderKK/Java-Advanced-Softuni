package _08Generics._02Exercise._02GenericBoxOfInteger;

public class Box<T> {
    private T value;

    public Box(T value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value.getClass().toString().substring(6) + ": " + value;
    }
}
