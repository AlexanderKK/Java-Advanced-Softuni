//package _09IteratorsAndComparators._02Exercise._04Froggy;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Integer> numbers = Arrays.stream(scanner.nextLine().split(", ")).map(Integer::parseInt).collect(Collectors.toList());

        Lake<Integer> lake = new Lake<>(numbers);

        String cmd = scanner.nextLine();

        StringBuilder sb = new StringBuilder();

        if(cmd.equals("END")) {
            lake.forEach(e -> sb.append(e).append(", "));
        }

        System.out.println(sb.substring(0, sb.length() - 2));
    }
}
