package _06DefiningClasses._02Exercise._02CompanyRoaster;

import java.util.*;

public class Department {
    private static final List<Employee> employees = new ArrayList<>();
    private static final Map<String, Double> departmentSalaries = new HashMap<>();

    public static void add(Employee employee) {
        employees.add(employee);

        departmentSalaries.putIfAbsent(employee.department(), 0.0);
        departmentSalaries.put(employee.department(), departmentSalaries.get(employee.department()) + employee.salary());
    }

    public static String bestDepartment() {
        return departmentSalaries.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null).getKey();
    }

    public static void printBestDepartment() {
        System.out.println("Highest Average Salary: " + bestDepartment());

        employees.stream()
                .filter(e -> e.department().equals(bestDepartment()))
                .sorted(Comparator.comparing(Employee::salary).reversed())
                .forEach(e -> System.out.printf("%s %.2f %s %d%n", e.name(), e.salary(), e.email(), e.age()));
    }
}
