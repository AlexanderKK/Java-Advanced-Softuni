package _06DefiningClasses._02Exercise._02CompanyRoaster;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split("\\s+");

            if(data.length == 6) {
                Department.add( new Employee(data[0], Double.parseDouble(data[1]), data[2], data[3], data[4], Integer.parseInt(data[5])) );
            } else if(data.length == 5 && isInteger(data[4])) {
                Department.add( new Employee(data[0], Double.parseDouble(data[1]), data[2], data[3], Integer.parseInt(data[4])) );
            } else if(data.length == 5 && !isInteger(data[4])) {
                Department.add( new Employee(data[0], Double.parseDouble(data[1]), data[2], data[3], data[4]) );
            } else {
                Department.add( new Employee(data[0], Double.parseDouble(data[1]), data[2], data[3]) );
            }
        }

        Department.printBestDepartment();
    }

    private static boolean isInteger(String str) {
        for (char c : str.toCharArray()) {
            if(!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }
}
