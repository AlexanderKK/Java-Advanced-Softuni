package _06DefiningClasses._02Exercise._03SpeedRacing;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //2
        //AudiA4 23 0.3
        //BMW-M2 45 0.42
        //Drive BMW-M2 56
        //Drive AudiA4 5
        //Drive AudiA4 13
        //End

        Set<Car> cars = new LinkedHashSet<>();

        //Enter cars
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split(" ");

            String model = data[0];
            int fuelAmount = Integer.parseInt(data[1]);
            double fuelCostPerKm = Double.parseDouble(data[2]);

            cars.add( new Car(model, fuelAmount, fuelCostPerKm) );
        }

        String command;
        while(!"End".equals(command = scanner.nextLine())) {
            String[] data = command.split(" ");

            String model = data[1];
            int kms = Integer.parseInt(data[2]);

            for (Car car : cars) {
                if(car.model().equals(model)) {
                    car.drive(model, kms);
                }
            }
        }

        cars.forEach(System.out::println);
    }
}
